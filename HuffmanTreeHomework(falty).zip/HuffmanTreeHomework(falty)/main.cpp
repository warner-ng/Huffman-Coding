// 用哈夫曼树实现文本文件压缩:
// 假设某一段文本只有英文（可以有标点和空格），
// 1、通过代码输入这段文本，然后统计各个字符出现的次数
// 2、构造 哈夫曼树
// 3、进行哈夫曼编
// 4、最后输出每个字符的哈夫曼编码结果，以及输出这段文本的哈夫曼编码结果

// 示例文本：
// I am too old to worry about who likes me and dislike me. 
// I have more important things to do. 
// If you love me, I love you.
// If you support me, I support you.
// If you hate me, I don't care.
// Life goes on with or without you.
// By Donald Trump


#include <iostream>
using namespace std;

// 从前k个数据里，选出双亲为零的权值最小的两个结点，把他们的下标i j返回
void findTwoMinIndices(int data[], int parent[], int size, int &i, int &j) {
    if (size < 2) {
        return;  // 如果数组小于2个元素，则无法找到两个最小值
    }

    // 初始化最小值和次小值，只考虑双亲为0的节点
    i = -1;
    j = -1;

    // 遍历前两个元素并初始化
    if (parent[0] == 0 && parent[1] == 0) { // 都是根节点
        if (data[0] < data[1]) {
            i = 0;
            j = 1;
        } else {
            i = 1;
            j = 0;
        }
    } else if (parent[0] == 0) {  // 只有data[0]是根节点
        i = 0;
        j = 1;
    } else if (parent[1] == 0) {  // 只有data[1]是根节点
        i = 1;
        j = 0;
    }

    // 遍历剩余的元素
    for (int index = 2; index < size; ++index) {
        if (parent[index] == 0) {  // 只有当双亲为零时，才参与比较
            if (i == -1 || data[index] < data[i]) {  // 找到更小的最小值
                j = i;  // 将原最小值的下标赋给 j
                i = index;  // 更新最小值的下标
            } else if (j == -1 || data[index] < data[j]) {  // 找到比次小值还小的元素
                j = index;  // 更新次小值的下标
            }
        }
    }

    // 最终输出找到的两个最小值下标
    if (i != -1 && j != -1) {
        cout << "Final smallest two indices: i = " << i << ", j = " << j << endl;
    } else {
        cout << "No valid nodes with parent 0 found." << endl;
    }
}


void CountWeight(int w[]){
     char text[] = "I am too old to worry about who likes me and dislike me. "
                  "I have more important things to do. "
                  "If you love me, I love you. "
                  "If you support me, I support you. "
                  "If you hate me, I don't care. "
                  "Life goes on with or without you.";

    // 记录字母频率的数组
    
    // 遍历字符数组，统计字母出现次数
    for (int i = 0; text[i] != '\0'; ++i) {
        char c = text[i];

        // 检查是否是字母（通过 ASCII 码范围判断）
        if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')) {
            // 转换为小写字母
            if (c >= 'A' && c <= 'Z') {
                c = c - 'A' + 'a';  // 将大写转为小写
            }

            // 更新对应字母的频率
            w[c - 'a']++;
        }
    }

    // 输出每个字母的频率
    cout << "Letter frequency:\n";
    for (int i = 0; i < 26; i++) {
        char letter = 'a' + i;
        cout << letter << ": " << w[i] << endl;
    }

    
}


// 使用 数组型 静态链表结构来构造哈夫曼树；每个结点由四个数据域组成，分别是Lchild Rchild data Prnt
void HuffmanTree(int n, int  Lchild[], int Rchild[], int data[], int Prnt[], int w[]){
    // n是要编码的字符个数，这里是26
    // Lchild Rchild data w 这几个数组都只有n个元素，对应n个要编码的字符
    // Prnt 这个数组有2n-1个元素，也就是这棵哈夫曼树一共有2n-1个结点


    int m = 2*n-1;  // 一棵有n个叶子结点的树，共有2n-1个结点

    for (int i=0; i<n; i++){
        data[i]=w[i]; // 把权值付给这个数
        Lchild[i]=0;  // 初始化一棵树
        Rchild[i]=0;  // 初始化一棵树
        cout<<"data"<<" "<<i<<"="<<w[i]<<endl;
    }

    for (int i=0; i<(2*n-1);i++){
        Prnt[i]=0;  // 初始化一棵树 （

    }

    for(int k=n ; k<(2*n-1); k++){
        // 选出双亲为零的 权值最小的两个结点，把他们的下标i j返回
        int i,j;
        findTwoMinIndices(data, Prnt, k , i, j);   // 小tips:将数组传入给函数的时候，不需要加[]，直接输入数组名即可
        


        // 组成哈夫曼树
        data[k]=data[i]+data[j];
        Lchild[k]=i;
        Rchild[k]=j;
        Prnt[i]=k;
        Prnt[j]=k;

    }

    cout << "Huffman Tree Structure:" << endl;
    for (int i = 0; i < m; i++) {
        cout << "Node " << i << ": ";
        cout << "Parent = " << Prnt[i] << ", ";
        cout << "Left Child = " << Lchild[i] << ", ";
        cout << "Right Child = " << Rchild[i] << ", ";
        cout << "Weight = " << data[i] << endl;
    }

}


void HuffmanCoding(int n, int Lchild[], int Rchild[], int Prnt[], char HC[][50]) {
    // 假设每个字符的最大编码长度不会超过50
    char temp[50]; // 临时存储单个编码的数组

    // 遍历所有叶子节点
    for (int i = 1; i <= n; ++i) {
        int k = 0;           // 当前编码的长度
        int child = i;
        int parent = Prnt[child];

        // 从叶子节点回溯到根节点
        while (parent != 0) {
            if (Lchild[parent] == child)
                temp[k++] = '0'; // 左子节点编码为'0'
            else
                temp[k++] = '1'; // 右子节点编码为'1'

            child = parent;
            parent = Prnt[child];
        }

        // 反转编码并保存到HC中
        // 确保不超出最大编码长度
        int j;
        for (j = 0; j < k; ++j) {
            HC[i][j] = temp[k - j - 1];
        }
        HC[i][j] = '\0'; // 添加字符串结束符
    }
}






int main(){
    int w[26] = {0};  // 存储字母频率
    CountWeight(w);  // 统计字母频率并输出

    // 假设文本中只有26个字母
    int n = 26;  // 英文字母的个数
    int Lchild[51] = {0}, Rchild[51] = {0}, data[51] = {0}, Prnt[51] = {0};
    char HC[26][50];  // 每个字母的哈夫曼编码

    // 构建哈夫曼树
    HuffmanTree(n, Lchild, Rchild, data, Prnt, w);

    // 获取哈夫曼编码
    HuffmanCoding(n, Lchild, Rchild, Prnt, HC);

    // 输出每个字母的哈夫曼编码
    cout << "\nCharacter Huffman Codes:\n";
    for (int i = 0; i < 26; i++) {
        if (w[i] > 0) {  // 如果字母出现过
            cout << (char)(i + 'a') << ": " << HC[i] << endl;
        }
    }

    // 输出文本的哈夫曼编码
    cout << "\nText Huffman Encoding:\n";
    char text[] = "I am too old to worry about who likes me and dislike me. "
                  "I have more important things to do. "
                  "If you love me, I love you. "
                  "If you support me, I support you. "
                  "If you hate me, I don't care. "
                  "Life goes on with or without you.";

    for (int i = 0; text[i] != '\0'; ++i) {
        char c = text[i];
        if (c >= 'A' && c <= 'Z') {
            cout << HC[c - 'A'];  // 输出大写字母的哈夫曼编码
        } else if (c >= 'a' && c <= 'z') {
            cout << HC[c - 'a'];  // 输出小写字母的哈夫曼编码
        } else {
            cout << c;  // 对于非字母字符直接输出
        }
    }
    cout << endl;

    system("pause");
    return 0;

}