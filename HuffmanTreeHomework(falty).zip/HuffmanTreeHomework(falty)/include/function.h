#ifndef FUNCTION_H  // 如果未定义 FUNCTION_H
#define FUNCTION_H  // 定义 FUNCTION_H


#endif  